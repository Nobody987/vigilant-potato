﻿namespace XML_Configurator.DatabaseConnect
{
    class ResultSetInstance
    {
        public string COLUMN_NAME;
        public string DATA_TYPE;
        public string IS_NULLABLE;
    }
}
